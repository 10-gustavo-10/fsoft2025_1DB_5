#ifndef MATCH_H
#define MATCH_H

#include <string>
#include "Team.h"

class Match {
private:
    Team* homeTeam;
    Team* awayTeam;
    int homeGoals;
    int awayGoals;
    bool played;

public:
    Match(Team* home, Team* away);

    void setResult(int homeGoals, int awayGoals);
    bool isPlayed() const;

    Team* getHomeTeam() const;
    Team* getAwayTeam() const;
    int getHomeGoals() const;
    int getAwayGoals() const;
};

#endif
