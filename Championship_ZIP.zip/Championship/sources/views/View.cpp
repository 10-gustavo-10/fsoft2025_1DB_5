#include "../../headers/views/View.h"
#include "../../headers/controllers/ChampionshipController.h"
#include <iostream>

void View::menu(ChampionshipController& controller) {
    int option;
    do {
        std::cout << "\n1. Register match result\n";
        std::cout << "2. Show standings\n";
        std::cout << "0. Exit\n";
        std::cout << "Choose an option: ";
        std::cin >> option;

        if (option == 1) {
            int id1, id2, g1, g2;
            const auto& teams = controller.getTeams();
            for (size_t i = 0; i < teams.size(); i++)
                std::cout << i << " - " << teams[i].name << '\n';

            std::cout << "Home team ID: "; std::cin >> id1;
            std::cout << "Away team ID: "; std::cin >> id2;
            std::cout << "Goals home team: "; std::cin >> g1;
            std::cout << "Goals away team: "; std::cin >> g2;

            controller.registerMatch(id1, id2, g1, g2);
        }
        else if (option == 2) {
            View::showStandings(controller.getTeams()); // uso com prefixo da classe, pois é static
        }

    } while (option != 0);
}

void View::showStandings(const std::vector<Team>& teams) {
    std::cout << "\n--- League Standings ---\n";
    for (const auto& t : teams) {
        std::cout << t.name << " | Points: " << t.points
                  << " | GS: " << t.goals_scored
                  << " | GC: " << t.goals_conceded
                  << " | Matches: " << t.matches << '\n';
    }
}




